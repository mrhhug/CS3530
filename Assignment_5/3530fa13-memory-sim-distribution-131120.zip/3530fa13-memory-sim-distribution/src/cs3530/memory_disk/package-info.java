/**
 *   Simulation of various paging algorithms.
 */
/**
 * @author Ben
 *
 */
package cs3530.memory_disk;