/**
 * 
 * Programs that just try out the various classes being created
 * for memory and disk simulation.
 * 
 */
/**
 * @author Ben
 *
 */
package cs3530.memory_disk.tryout;